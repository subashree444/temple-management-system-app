package org.amfoss.templeapp.Util;

public class Constants {
    public static final String DB_DONATION_NAME = "donations";
    public static final String DB_POOJA_NAME = "poojas";
    public static final String DB_EXPENSE_NAME = "expenses";
    public static final String PILGRIM_NAME = "pilgrimName";
    public static final String DB_PROFILE = "profile";
    public static final String DB_MEMBERS = "members";
    public static final String EXPENSE_DESCRIPTION = "expenseDescription";
}
