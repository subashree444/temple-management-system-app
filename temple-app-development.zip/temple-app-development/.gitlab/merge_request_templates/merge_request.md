Closes #[Add issue number here. If you do not solve the issue entirely, please change the message e.g. "First steps for issues #IssueNumber]

Changes: [Mention the files changed in the PR. Add here what changes were made in this issue and if possible provide links(Deploy/Preview Link).]

Screenshots of the change: 
